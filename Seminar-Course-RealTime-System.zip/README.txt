Kafka Presentation (Beamer LaTeX)
=================================
This starter folder contains a multi-file LaTeX presentation.

Files:
- main.tex ........... main entry file
- log_aggregation.tex  slides for log aggregation project
- order_tracking.tex   slides for order tracking project
- summary.tex ........ final summary & future work

To compile:
    pdflatex main.tex

You can add logos, diagrams, or screenshots in the same folder.
